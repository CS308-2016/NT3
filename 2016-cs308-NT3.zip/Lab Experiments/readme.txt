Group A 
Name: Harinandan Teja
Roll No: 120050066
Name: Sumanth Vakulabharanam
Roll No: 120050069

Group B
Name: Venkata Dinesh Kota
Roll No: 120050051
Name: Sundeep Routhu
Roll No: 120050048


Add a well documented and commented code of your experiments in the respective folders.
