Project Name: NT3(Non Touch To Touch)

Team Members:
1. Harinandan Teja (Roll Number)
2. Dinesh Kota (120050051)
3. Sundeep Routhu (120050048) 
4. Sumanth V (120050069)

Project Description:
