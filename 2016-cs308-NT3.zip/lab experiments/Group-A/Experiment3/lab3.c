#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "inc/hw_gpio.h"
#include "driverlib/rom.h"

//We’ll use a 55Hz base frequency to control the servo
#define PWM_FREQUENCY 55

volatile uint8_t ui8AdjustR;
volatile uint8_t ui8AdjustB;
volatile uint8_t ui8AdjustG;
volatile uint8_t ui8AdjustMax;
volatile uint8_t ui8AdjustMin;
volatile uint16_t angle;
int mode;

int main(void)
{
	volatile uint32_t ui32Load;
	volatile uint32_t ui32PWMClock;
	angle = 0;
	ui8AdjustMax = 244;
	ui8AdjustMin = 10;
	ui8AdjustR = ui8AdjustMax;
	ui8AdjustB = 0;
	ui8AdjustG = 0;

	/*Let’s run the CPU at 40MHz. The PWM module is clocked by the system clock through
	a divider, and that divider has a range of 2 to 64. By setting the divider to 64, it will run
	the PWM clock at 625 kHz. Note that we’re using the ROM versions to reduce our code size*/
	SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_OSC_MAIN|SYSCTL_XTAL_16MHZ);
	SysCtlPWMClockSet(SYSCTL_PWMDIV_64);

	/*We need to enable the PWM1 and the GPIOF module (for the LaunchPad buttons on PF0
	and PF4 and PWM output on PF1)*/
	SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

	/*Port F pin 1 (PF1) must be configured as a PWM output pin for module 1, PWM
	generator 2 (check out the schematic)*/
	GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_1);
	GPIOPinConfigure(GPIO_PF1_M1PWM5);
	GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);
	GPIOPinConfigure(GPIO_PF2_M1PWM6);
	GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_3);
	GPIOPinConfigure(GPIO_PF3_M1PWM7);

	/*Port F pin 0 and pin 4 are connected to the S2 and S1 switches on the LaunchPad. In
	order for the state of the pins to be read in our code, the pins must be pulled up. (The
	BUTTONSPOLL API could do this for us, but that API checks for individual button
	presses rather than a button being held down). Pulling up a GPIO pin is normally pretty
	straight-forward, but PF0 is considered a critical peripheral since it can be configured to
	be a NMI input. Since this is the case, we will have to unlock the GPIO commit control
	register to make this change. This feature was mentioned in chapter 3 of the workshop.
	The first three lines below unlock the GPIO commit control register, the fourth
	configures PF0 & 4 as inputs and the fifth configures the internal pull-up resistors on
	both pins. The drive strength setting is merely a place keeper and has no function for an
	input*/
	HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;
	HWREG(GPIO_PORTF_BASE + GPIO_O_CR) |= 0x01;
	HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = 0;
	GPIODirModeSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_DIR_MODE_IN);
	GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);

	/*The PWM clock is SYSCLK/64 (set in step 12 above). Divide the PWM clock by the
	desired frequency (55Hz) to determine the count to be loaded into the Load register. Then
	subtract 1 since the counter down-counts to zero. Configure module 1 PWM generator 2
	as a down-counter and load the count value*/
	ui32PWMClock = SysCtlClockGet() / 64;
	ui32Load = (ui32PWMClock / PWM_FREQUENCY) - 1;
	PWMGenConfigure(PWM1_BASE, PWM_GEN_2, PWM_GEN_MODE_DOWN);
	PWMGenPeriodSet(PWM1_BASE, PWM_GEN_2, ui32Load);
	PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN);
	PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3, ui32Load);

	/*Now we can make the final PWM settings and enable it. The first line sets the pulsewidth.
	The PWM Load value is divided by 1000 (which determines the minimum
	resolution for the servo) and the multiplied by the adjusting value. These numbers could
	be changed to provide more or less resolution. In lines two and three, PWM module 1,
	generator 2 needs to be enabled as an output and enabled to run*/
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);
	PWMOutputState(PWM1_BASE, PWM_OUT_5_BIT, true);
	PWMOutputState(PWM1_BASE, PWM_OUT_6_BIT, true);
	PWMOutputState(PWM1_BASE, PWM_OUT_7_BIT, true);
	PWMGenEnable(PWM1_BASE, PWM_GEN_2);
	PWMGenEnable(PWM1_BASE, PWM_GEN_3);

	mode = 0;
	int time = 1000000;
	while(1)
	{
		/* mode = 0 means we are in auto mode.
		In Auto mode color of the RGB LED follows a pattern in a cycle.
		The pattern must follow the color circle as shown in Figure 1.
		In Auto mode SW1 will increase the speed of color transition and SW2 will decrease the speed*/
		if(mode == 0){
			angle = angle + 1;
			if(angle >= 360){
				angle = 0;
			}
			if(angle < 120){
				ui8AdjustG = ui8AdjustMin + angle * ui8AdjustMax / 120.0;
				ui8AdjustR = ui8AdjustMin + ui8AdjustMax - ui8AdjustG;
				ui8AdjustB = ui8AdjustMin;
			} else if (angle < 240){
				ui8AdjustB = ui8AdjustMin + (angle - 120) * ui8AdjustMax / 120.0;
				ui8AdjustG = ui8AdjustMin + ui8AdjustMax - ui8AdjustB;
				ui8AdjustR = ui8AdjustMin;
			} else if(angle < 360){
				ui8AdjustR = ui8AdjustMin + (angle - 240) * ui8AdjustMax / 120.0;
				ui8AdjustB = ui8AdjustMin + ui8AdjustMax - ui8AdjustR;
				ui8AdjustG = ui8AdjustMin;
			}
			PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
			PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
			PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);

			SysCtlDelay(time);
			/*This code will read the PF4 pin to see if SW1 is pressed. No debouncing is needed since
			we’re not looking for individual key pressed. Each time this code is run it will check the time
			duration for which the key has been pressed.*/
			if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00)
			{
				time += 100000;
				if(time >= 2000000)time = 2000000;
			}
			/*This code will read the PF0 pin to see if SW2 is pressed. Each time this code is run it will check the time
			duration for which the key has been pressed.*/
			if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0x00)
			{
				time -= 100000;
				if(time <= 100000)time = 100000;
			}
		}
		while(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0x00){
			if((GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00) && mode < 4){
				// checking for the changes in manual mode and auto mode
				mode++;
			}
			SysCtlDelay(2000000);
		}

		/* mode = 1 means we are in manual mode 1. When SW2 is pressed continuously(long press) and SW1 is pressed
		once controller goes to Manual Mode 1. In this mode, intensity of Red LED can be controlled using
		SW1 and SW2 */
		if(mode == 1){
			ui8AdjustR = 127;
			ui8AdjustB = 10;
			ui8AdjustG = 10;
			int count = 0;
			while(1){
				if(count != 0){
					mode = count;
					break;
				}
				/*This code will read the PF4 pin to see if SW1 is pressed. No debouncing is needed since
				we’re not looking for individual key pressed. Each time this code is run it will check the time
				duration for which the key has been pressed.*/
				if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00)
				{
					ui8AdjustR--;
					if (ui8AdjustR < 10)
					{
						ui8AdjustR = 10;
					}
				}
				/*This code will read the PF0 pin to see if SW2 is pressed. Each time this code is run it will check the time
				duration for which the key has been pressed.*/
				if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0x00)
				{
					ui8AdjustR += 5;
					if (ui8AdjustR > 254)
					{
						ui8AdjustR = 254;
					}
					while(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0x00){
						if((GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00) && count < 4){
							count++;
						}
						SysCtlDelay(2000000);
					}
				}
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);

				SysCtlDelay(100000);
			}
		}

		/* mode = 2 means we are in manual mode 2. When SW2 is pressed continuously(long press) and SW1 is pressed
		twice controller goes to Manual Mode 2. In this mode, intensity of Blue LED can be controlled using
		SW1 and SW2 */
		else if (mode == 2){
			ui8AdjustB = 127;
			ui8AdjustR = 10;
			ui8AdjustG = 10;
			int count = 0;
			while(1){
				if(count != 0){
					mode = count;
					break;
				}
				/*This code will read the PF4 pin to see if SW1 is pressed. No debouncing is needed since
				we’re not looking for individual key pressed. Each time this code is run it will check the time
				duration for which the key has been pressed.*/
				if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00)
				{
					ui8AdjustB--;
					if (ui8AdjustB < 10)
					{
						ui8AdjustB = 10;
					}
				}
				/*This code will read the PF0 pin to see if SW2 is pressed. Each time this code is run it will check the time
				duration for which the key has been pressed.*/
				if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0x00)
				{
					ui8AdjustB += 5;
					if (ui8AdjustB > 254)
					{
						ui8AdjustB = 254;
					}
					while(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0x00){
						if((GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00) && count < 4){
							count++;
						}
						SysCtlDelay(2000000);
					}
				}
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);

				SysCtlDelay(100000);
			}
		}

		/* mode = 3 means we are in manual mode 2. When SW1 and SW2 are pressed continuously controller goes to
		Manual Mode 3. In this mode, intensity of Green LED can be controlled using SW1 and SW2 */
		else if(mode > 2){
			ui8AdjustG = 127;
			ui8AdjustB = 10;
			ui8AdjustR = 10;
			int count = 0;
			while(1){
				if(count != 0){
					mode = count;
					break;
				}
				/*This code will read the PF4 pin to see if SW1 is pressed. No debouncing is needed since
				we’re not looking for individual key pressed. Each time this code is run it will check the time
				duration for which the key has been pressed.*/
				if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00)
				{
					ui8AdjustG--;
					if (ui8AdjustG < 10)
					{
						ui8AdjustG = 10;
					}
				}
				/*This code will read the PF0 pin to see if SW2 is pressed. Each time this code is run it will check the time
				duration for which the key has been pressed.*/
				if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0)==0x00)
				{
					ui8AdjustG += 5;
					if (ui8AdjustG > 254)
					{
						ui8AdjustG = 254;
					}
					while(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0x00){
						if((GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0x00) && count < 4){
							count++;
						}
						SysCtlDelay(2000000);
					}
				}
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);

				SysCtlDelay(100000);
			}
		}
	}
}
