#include<stdint.h>
#include<stdio.h>
#include<stdbool.h>
#include"inc/hw_memmap.h"
#include"inc/hw_types.h"
#include"inc/hw_gpio.h"
#include"driverlib/gpio.h"
#include"driverlib/pin_map.h"
#include"driverlib/sysctl.h"
#include"driverlib/uart.h"
#include"driverlib/debug.h"
#include"driverlib/adc.h"
#include"driverlib/pwm.h"
#include"driverlib/rom.h"

#define PWM_FREQUENCY 55
volatile uint8_t ui8AdjustR;
volatile uint8_t ui8AdjustB;
volatile uint8_t ui8AdjustG;
volatile uint8_t ui8AdjustMax;
volatile uint8_t ui8AdjustMin;
volatile uint16_t angle;
int mode = 0;

int main(void) {
	char t1, t2;
	volatile uint32_t ui32Load;
	volatile uint32_t ui32PWMClock;
	angle = 0;
	ui8AdjustMax = 244;
	ui8AdjustMin = 10;
	ui8AdjustR = ui8AdjustMax;
	ui8AdjustB = 0;
	ui8AdjustG = 0;
	t1 = '0';
	t2 = '0';
	/*The following definition will create an array that will be used for storing the data read
	from the ADC FIFO. It must be as large as the FIFO for the sequencer in use. We will be
	using sequencer 1 which has a FIFO depth of 4. If another sequencer was used with a
	smaller or deeper FIFO, then the array size would have to be changed. For instance, sequencer
	0 has a depth of 8*/
	uint32_t ui32ADC0Value[4];

	/*We’ll need some variables for calculating the temperature from the sensor data. The first
	variable is for storing the average of the temperature. The remaining variables are used to
	store the temperature values for Celsius and Fahrenheit. All are declared as 'volatile' so
	that each variable cannot be optimized out by the compiler and will be available to the
	'Expression' or 'Local' window(s) at run-time*/
	volatile uint32_t ui32TempAvg;
	volatile uint32_t ui32TempValueC;
	volatile uint32_t ui32TempValueF;
	volatile uint32_t ui32SetTempValueC = 24;

	//Set up the system clock again to run at 40MHz
	SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_OSC_MAIN|SYSCTL_XTAL_16MHZ);
	//Let’s enable the ADC0 peripheral next
	SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);

	/*Now, we can configure the ADC sequencer. We want to use ADC0, sample sequencer 1,
	we want the processor to trigger the sequence and we want to use the highest priority*/
	ADCSequenceConfigure(ADC0_BASE, 1, ADC_TRIGGER_PROCESSOR, 0);

	/*Next we need to configure all four steps in the ADC sequencer. Configure steps 0
	sequencer 1 to sample the temperature sensor (ADC_CTL_TS). In this example, our
	code will average all four samples of temperature sensor data on sequencer 1 to calculate
	the temperature, so all four sequencer steps will measure the temperature sensor. For
	more information on the ADC sequencers and steps, reference the device specific
	datasheet*/
	ADCSequenceStepConfigure(ADC0_BASE, 1, 0, ADC_CTL_TS);
	ADCSequenceStepConfigure(ADC0_BASE, 1, 1, ADC_CTL_TS);
	ADCSequenceStepConfigure(ADC0_BASE, 1, 2, ADC_CTL_TS);

	/*The final sequencer step requires a couple of extra settings. Sample the temperature
	sensor (ADC_CTL_TS) and configure the interrupt flag (ADC_CTL_IE) to be set
	when the sample is done. Tell the ADC logic that this is the last conversion on sequencer
	1 (ADC_CTL_END) */
	ADCSequenceStepConfigure(ADC0_BASE,1,3,ADC_CTL_TS|ADC_CTL_IE|ADC_CTL_END);

	//Now we can enable ADC sequencer 1
	ADCSequenceEnable(ADC0_BASE, 1);

	SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	GPIOPinConfigure(GPIO_PA0_U0RX);
	GPIOPinConfigure(GPIO_PA1_U0TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));

	SysCtlPWMClockSet(SYSCTL_PWMDIV_64);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF); //enable GPIO port for LED
	GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_1);
	GPIOPinConfigure(GPIO_PF1_M1PWM5);
	GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);
	GPIOPinConfigure(GPIO_PF2_M1PWM6);
	GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_3);
	GPIOPinConfigure(GPIO_PF3_M1PWM7);
	HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;
	HWREG(GPIO_PORTF_BASE + GPIO_O_CR) |= 0x01;
	HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = 0;
	GPIODirModeSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_DIR_MODE_IN);
	GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
	ui32PWMClock = SysCtlClockGet() / 64;
	ui32Load = (ui32PWMClock / PWM_FREQUENCY) - 1;
	PWMGenConfigure(PWM1_BASE, PWM_GEN_2, PWM_GEN_MODE_DOWN);
	PWMGenPeriodSet(PWM1_BASE, PWM_GEN_2, ui32Load);
	PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN);
	PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3, ui32Load);
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);
	PWMOutputState(PWM1_BASE, PWM_OUT_5_BIT, true);
	PWMOutputState(PWM1_BASE, PWM_OUT_6_BIT, true);
	PWMOutputState(PWM1_BASE, PWM_OUT_7_BIT, true);
	PWMGenEnable(PWM1_BASE, PWM_GEN_2);
	PWMGenEnable(PWM1_BASE, PWM_GEN_3);

	//let interrupt handler do the UART echo function
	while(1)
	{
		while(!mode){
			//The indication that the ADC conversion process is complete will be the ADC interrupt status flag
			ADCIntClear(ADC0_BASE, 1);

			//Now we can trigger the ADC conversion with software. ADC conversions can be triggered by many other sources
			ADCProcessorTrigger(ADC0_BASE, 1);

			//We need to wait for the conversion to complete
			while(!ADCIntStatus(ADC0_BASE, 1, false))
			{
			}

			/*When code execution exits the loop in the previous step, we know that the conversion is
			complete andthat we can read the ADC value from the ADC Sample Sequencer 1 FIFO.
			The function we’ll be using copies data from the specified sample sequencer output FIFO
			to a buffer in memory. The number of samples available in the hardware FIFO are copied
			into the buffer, which must be large enough to hold that many samples. This will only
			return the samples that are presently available, which might not be the entire sample
			sequenceif you attempt to access the FIFO before the conversion is complete*/
			ADCSequenceDataGet(ADC0_BASE, 1, ui32ADC0Value);

			//Calculate the average of the temperature sensor data
			ui32TempAvg = (ui32ADC0Value[0] + ui32ADC0Value[1] + ui32ADC0Value[2] + ui32ADC0Value[3] + 2)/4;

			/*Now that we have the averaged reading from the temperature sensor, we can calculate the
			Celsius value of the temperature. The equation below is shown in theTM4C123GH6PM
			datasheet. Division is performed last to avoid truncation due to integer math rules.
			We need to multiply everything by 10 to stay within the precision needed. The divide by
			10 at the end is needed to get the right answer. VREFP – VREFN is Vdd or 3.3 volts.
			We’ll multiply it by 10, and then 75 to get 2475*/
			ui32TempValueC = (1475 - ((2475 * ui32TempAvg)) / 4096)/10;

			//Once you have the Celsius temperature, calculating the Fahrenheit temperature is easy
			ui32TempValueF = ((ui32TempValueC * 9) + 160) / 5;
			if(ui32TempValueC < 10){
				t1 = '0';
				t2 = '0' + ui32TempValueC;
			}
			else{
				t1 = '0' + ui32TempValueC/10;
				t2 = '0' + ui32TempValueC%10;
			}
			if(ui32TempValueC < ui32SetTempValueC){
				//green
				ui8AdjustG = 127;
				ui8AdjustB = 1;
				ui8AdjustR = 1;
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);
			}
			else{
				//red
				ui8AdjustG = 1;
				ui8AdjustB = 1;
				ui8AdjustR = 127;
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, ui8AdjustR * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, ui8AdjustB * ui32Load / 1000);
				PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, ui8AdjustG * ui32Load / 1000);
			}
			UARTCharPut(UART0_BASE, '\f');
			UARTCharPut(UART0_BASE, 'C');
			UARTCharPut(UART0_BASE, 'u');
			UARTCharPut(UART0_BASE, 'r');
			UARTCharPut(UART0_BASE, 'r');
			UARTCharPut(UART0_BASE, 'e');
			UARTCharPut(UART0_BASE, 'n');
			UARTCharPut(UART0_BASE, 't');
			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, 'T');
			UARTCharPut(UART0_BASE, 'e');
			UARTCharPut(UART0_BASE, 'm');
			UARTCharPut(UART0_BASE, 'p');
			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, t1);
			UARTCharPut(UART0_BASE, t2);
			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, '^');
			UARTCharPut(UART0_BASE, 'C');

			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, ',');
			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, 'S');
			UARTCharPut(UART0_BASE, 'e');
			UARTCharPut(UART0_BASE, 't');
			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, 'T');
			UARTCharPut(UART0_BASE, 'e');
			UARTCharPut(UART0_BASE, 'm');
			UARTCharPut(UART0_BASE, 'p');
			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, '0'+ui32SetTempValueC/10);
			UARTCharPut(UART0_BASE, '0'+ui32SetTempValueC%10);
			UARTCharPut(UART0_BASE, ' ');
			UARTCharPut(UART0_BASE, 167);
			UARTCharPut(UART0_BASE, 'C');

			//loop while there are chars
			if (UARTCharsAvail(UART0_BASE)){
				char c;
				c = UARTCharGet(UART0_BASE);
				if(c == 'S'){
					mode = 1;
					break;
				}
			}

			//delay 1 sec
			SysCtlDelay(10000000);
		}
		UARTCharPut(UART0_BASE, '\f');
		UARTCharPut(UART0_BASE, 'E');
		UARTCharPut(UART0_BASE, 'n');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, 'r');
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, 'h');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, 'm');
		UARTCharPut(UART0_BASE, 'p');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, 'r');
		UARTCharPut(UART0_BASE, 'a');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, 'u');
		UARTCharPut(UART0_BASE, 'r');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, ':');
		UARTCharPut(UART0_BASE, ' ');
		ui32SetTempValueC = 0;
		while(1){
			char input = UARTCharGet(UART0_BASE);
			UARTCharPut(UART0_BASE, input);
			if(input == 13)break;
			ui32SetTempValueC = 10 * ui32SetTempValueC + input - '0';
		}
		UARTCharPut(UART0_BASE, '\f');
		UARTCharPut(UART0_BASE, 'S');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, 'T');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, 'm');
		UARTCharPut(UART0_BASE, 'p');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, 'r');
		UARTCharPut(UART0_BASE, 'a');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, 'u');
		UARTCharPut(UART0_BASE, 'r');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, 'u');
		UARTCharPut(UART0_BASE, 'p');
		UARTCharPut(UART0_BASE, 'd');
		UARTCharPut(UART0_BASE, 'a');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, 'e');
		UARTCharPut(UART0_BASE, 'd');
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, 't');
		UARTCharPut(UART0_BASE, 'o');
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, '0' + ui32SetTempValueC/10);
		UARTCharPut(UART0_BASE, '0' + ui32SetTempValueC%10);
		UARTCharPut(UART0_BASE, ' ');
		UARTCharPut(UART0_BASE, '^');
		UARTCharPut(UART0_BASE, 'C');
		mode = 0;
		SysCtlDelay(50000000);
		UARTCharPut(UART0_BASE, '\f');
	}
}
