2016 - CS308  Group 13 : Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
+   Harinandan Teja (120050066) 
+   Sundeep Routhu (120050048) 
+	Sumanth V (120050069)
+	Dinesh Kota (120050051)
 
Extension Of 
------------ 

Project Description 
------------------- 
 
This is a reame template. It is written using markdown syntax. To know more about markdown you can alwats refer to [Daring Fireball](http://daringfireball.net/projects/markdown/basics).  
You can preview how your mardown looks when rendered [here](http://daringfireball.net/projects/markdown/dingus) 
 
Students are requested to use this format for the sake of uniformity and convinience. Also we can parse these files and then index them for easy searching.  
 
Technologies Used 
------------------- 
 
+   OpenCV 
 
Installation Instructions 
=========================  

We need opencv and xdotool for the project
xdotool : sudo apt-get install xdotool
opencv : [links]https://github.com/Itseez/opencv/archive/3.1.0.zip
 
Demonstration Video 
=========================  
Add the youtube link of the screencast of your project demo.
https://www.cse.iitb.ac.in/~harikatam/

References 
=========== 
 
Please give references to importance resources.  
 
+ [OpenCV](http://opencv.org)

