#! /bin/bash
# mouse left click
xdotool click 1