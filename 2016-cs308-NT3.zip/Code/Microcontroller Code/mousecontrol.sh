#! /bin/bash
# move the mouse  x    y
xdotool mousemove $1 $2

